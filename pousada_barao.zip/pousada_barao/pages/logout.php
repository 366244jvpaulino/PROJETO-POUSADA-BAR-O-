<?php
// pages/logout.php
require_once '../includes/config.php';
session_destroy();
header('Location: /pousada_barao/index.php');
exit;
