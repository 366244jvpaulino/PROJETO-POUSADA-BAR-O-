<?php
// pages/quartos.php – Página de quartos
$page_title = 'Quartos';
require_once '../includes/header.php';

$quartos  = unserialize(QUARTOS_CONFIG);
$servicos = unserialize(SERVICOS);
?>

<section class="section section--bege" style="padding-top:3rem;padding-bottom:2rem">
  <div class="container text-center">
    <span class="section-label">Acomodações</span>
    <h1 class="section-title">Nossos Quartos</h1>
    <p class="section-sub">Temos opções para 1 a 8 pessoas. Todos com Wi-Fi, TV e café da manhã inclusos.</p>
  </div>
</section>

<section class="section">
  <div class="container">
    <div class="rooms-grid">
      <?php foreach ($quartos as $i => $q):
        $num = $i + 1; ?>
        <div class="room-card">
          <div class="room-card__img" style="font-size:2.5rem"><?= $q['emoji'] ?></div>
          <div class="room-card__body">
            <div class="room-card__qty">Capacidade: <?= $q['label'] ?></div>
            <div class="room-card__title">Quarto para <?= $q['label'] ?></div>
            <p class="room-card__desc">
              Ambiente aconchegante com Wi-Fi de alta velocidade, TV, roupa de cama e toalha.
              Café da manhã incluso. Banheiro compartilhado com outros hóspedes.
            </p>
            <ul style="font-size:0.84rem;color:#666;margin:0 0 1rem;padding-left:1.2rem">
              <?php foreach ($servicos as $s): ?>
                <li><?= $s['icon'] ?> <?= $s['nome'] ?></li>
              <?php endforeach; ?>
            </ul>
            <div class="room-card__footer">
              <span class="room-card__badge">
                <?= $q['quantidade'] ?> unidade<?= $q['quantidade'] > 1 ? 's' : '' ?>
              </span>
              <a href="https://wa.me/<?= POUSADA_WHATSAPP ?>?text=Olá!%20Gostaria%20de%20reservar%20um%20quarto%20para%20<?= urlencode($q['label']) ?>."
                 class="btn btn-primary" target="_blank" style="font-size:0.8rem;padding:0.5rem 1rem">
                📱 Reservar
              </a>
            </div>
          </div>
        </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- FORMULÁRIO DE AGENDAMENTO -->
<section class="section section--cinza">
  <div class="container" style="max-width:680px">
    <div class="text-center">
      <span class="section-label">Agende sua estadia</span>
      <h2 class="section-title">Solicitar reserva</h2>
      <p class="section-sub">Preencha o formulário e entraremos em contato para confirmar.</p>
    </div>

    <?php
    $msg = '';
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $nome       = trim(htmlspecialchars($_POST['nome'] ?? ''));
        $email      = trim(htmlspecialchars($_POST['email'] ?? ''));
        $telefone   = trim(htmlspecialchars($_POST['telefone'] ?? ''));
        $capacidade = trim(htmlspecialchars($_POST['capacidade'] ?? ''));
        $checkin    = trim(htmlspecialchars($_POST['checkin'] ?? ''));
        $checkout   = trim(htmlspecialchars($_POST['checkout'] ?? ''));
        $obs        = trim(htmlspecialchars($_POST['obs'] ?? ''));

        if ($nome && $email && $checkin && $checkout && $capacidade) {
            // Salva solicitação em arquivo de texto (simples, sem banco de dados)
            $linha = date('d/m/Y H:i') . " | $nome | $email | $telefone | Quarto p/ $capacidade | Entrada: $checkin | Saída: $checkout | $obs\n";
            file_put_contents('../reservas.txt', $linha, FILE_APPEND | LOCK_EX);
            $msg = '<div class="form-msg form-msg--ok">✅ Solicitação enviada! Entraremos em contato em breve pelo WhatsApp ou e-mail.</div>';
        } else {
            $msg = '<div class="form-msg form-msg--err">⚠️ Preencha todos os campos obrigatórios.</div>';
        }
    }
    echo $msg;
    ?>

    <form method="POST" action="">
      <div class="form-row">
        <div class="form-group">
          <label for="nome">Nome completo *</label>
          <input type="text" id="nome" name="nome" placeholder="Seu nome" required>
        </div>
        <div class="form-group">
          <label for="email">E-mail *</label>
          <input type="email" id="email" name="email" placeholder="seu@email.com" required>
        </div>
      </div>
      <div class="form-row">
        <div class="form-group">
          <label for="telefone">Telefone / WhatsApp</label>
          <input type="tel" id="telefone" name="telefone" placeholder="(19) 99999-9999">
        </div>
        <div class="form-group">
          <label for="capacidade">Quarto (capacidade) *</label>
          <select id="capacidade" name="capacidade" required>
            <option value="">Selecione...</option>
            <?php foreach ($quartos as $q): ?>
              <option value="<?= $q['label'] ?>">Para <?= $q['label'] ?> (<?= $q['quantidade'] ?> disponível<?= $q['quantidade'] > 1 ? 'is' : '' ?>)</option>
            <?php endforeach; ?>
          </select>
        </div>
      </div>
      <div class="form-row">
        <div class="form-group">
          <label for="checkin">Data de entrada *</label>
          <input type="date" id="checkin" name="checkin" required min="<?= date('Y-m-d') ?>">
        </div>
        <div class="form-group">
          <label for="checkout">Data de saída *</label>
          <input type="date" id="checkout" name="checkout" required min="<?= date('Y-m-d') ?>">
        </div>
      </div>
      <div class="form-group">
        <label for="obs">Observações</label>
        <textarea id="obs" name="obs" placeholder="Alguma necessidade especial, dúvida..."></textarea>
      </div>
      <button type="submit" class="btn btn-primary" style="width:100%">📨 Enviar solicitação de reserva</button>
    </form>
  </div>
</section>

<?php require_once '../includes/footer.php'; ?>
