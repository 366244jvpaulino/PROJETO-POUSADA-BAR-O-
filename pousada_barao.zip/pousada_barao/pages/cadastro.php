<?php
// pages/cadastro.php
$page_title = 'Cadastrar';
require_once '../includes/config.php';

if (isset($_SESSION['usuario_nome'])) {
    header('Location: /pousada_barao/index.php'); exit;
}

$erro = $sucesso = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $tipo  = $_POST['tipo']  ?? 'cliente';
    $nome  = trim(htmlspecialchars($_POST['nome']  ?? ''));
    $email = trim(htmlspecialchars($_POST['email'] ?? ''));
    $senha = $_POST['senha'] ?? '';
    $conf  = $_POST['conf']  ?? '';

    if (!$nome || !$email || !$senha) {
        $erro = 'Preencha todos os campos obrigatórios.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $erro = 'E-mail inválido.';
    } elseif (strlen($senha) < 6) {
        $erro = 'A senha precisa ter pelo menos 6 caracteres.';
    } elseif ($senha !== $conf) {
        $erro = 'As senhas não coincidem.';
    } else {
        $arquivo = '../usuarios.txt';
        // Verifica se e-mail já existe
        $existe = false;
        if (file_exists($arquivo)) {
            foreach (file($arquivo, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) as $linha) {
                $d = explode('|', $linha);
                if (count($d) >= 3 && trim($d[2]) === $email) { $existe = true; break; }
            }
        }
        if ($existe) {
            $erro = 'Este e-mail já está cadastrado. Faça login.';
        } else {
            $hash = password_hash($senha, PASSWORD_DEFAULT);
            file_put_contents($arquivo, "$tipo|$nome|$email|$hash\n", FILE_APPEND | LOCK_EX);
            $sucesso = 'Cadastro realizado! Agora você pode fazer login.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width,initial-scale=1.0">
  <title>Cadastrar | <?= POUSADA_NOME ?></title>
  <link rel="stylesheet" href="/pousada_barao/css/style.css">
</head>
<body>

<div class="auth-wrapper">
  <div class="auth-card" style="max-width:480px">

    <div class="auth-card__logo">
      <img src="/pousada_barao/img/cartao_visita.jpg" alt="Logo Pousada Barão"
           style="width:160px;border-radius:10px;margin:0 auto 1rem;display:block;box-shadow:0 4px 14px rgba(0,0,0,0.12)">
      <h2>Criar conta</h2>
      <p>Cadastre-se para gerenciar suas reservas</p>
    </div>

    <form method="POST" action="">
      <!-- Abas -->
      <div class="auth-tabs">
        <label class="auth-tab <?= ($_POST['tipo'] ?? 'cliente') === 'cliente' ? 'active' : '' ?>"
               onclick="setTipo('cliente')">👤 Cliente</label>
        <label class="auth-tab <?= ($_POST['tipo'] ?? '') === 'empresa' ? 'active' : '' ?>"
               onclick="setTipo('empresa')">🏢 Empresa</label>
      </div>
      <input type="hidden" name="tipo" id="tipo" value="<?= htmlspecialchars($_POST['tipo'] ?? 'cliente') ?>">

      <?php if ($erro):    ?><div class="alert alert-danger">⚠️ <?= $erro ?></div><?php endif; ?>
      <?php if ($sucesso): ?><div class="alert alert-success">✅ <?= $sucesso ?> <a href="login.php">Entrar</a></div><?php endif; ?>

      <div class="form-group">
        <label for="nome">Nome completo *</label>
        <input type="text" id="nome" name="nome" placeholder="Seu nome completo"
               value="<?= htmlspecialchars($_POST['nome'] ?? '') ?>" required>
      </div>
      <div class="form-group">
        <label for="email">E-mail *</label>
        <input type="email" id="email" name="email" placeholder="seu@email.com"
               value="<?= htmlspecialchars($_POST['email'] ?? '') ?>" required>
      </div>
      <div class="form-row">
        <div class="form-group">
          <label for="senha">Senha * <small style="font-weight:400;color:#aaa">(mín. 6 caracteres)</small></label>
          <input type="password" id="senha" name="senha" placeholder="Crie uma senha" required>
        </div>
        <div class="form-group">
          <label for="conf">Confirmar senha *</label>
          <input type="password" id="conf" name="conf" placeholder="Repita a senha" required>
        </div>
      </div>
      <button type="submit" class="btn btn-primary" style="width:100%;margin-bottom:1rem">Criar conta</button>
    </form>

    <div class="auth-footer">
      Já tem conta? <a href="login.php">Entrar</a>
      &nbsp;·&nbsp;
      <a href="/pousada_barao/index.php">← Voltar ao site</a>
    </div>
  </div>
</div>

<script>
function setTipo(v) {
  document.getElementById('tipo').value = v;
  document.querySelectorAll('.auth-tab').forEach(t => t.classList.remove('active'));
  event.target.classList.add('active');
}
</script>
</body>
</html>
