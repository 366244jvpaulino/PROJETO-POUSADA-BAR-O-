<?php
// pages/atracoes.php – Atrações próximas em Araras – SP
$page_title = 'Atrações';
require_once '../includes/header.php';

$atracoes = [
    ['nome' => 'Lavanderia DMO',              'tipo' => 'Serviço',       'emoji' => '👕', 'distancia' => '2 min a pé',     'desc' => 'Lavanderia conveniente a passos da pousada, ideal para hóspedes em estadia prolongada.'],
    ['nome' => 'Complexo de Serviços Malibu', 'tipo' => 'Serviço',       'emoji' => '🛍️', 'distancia' => '3 min a pé',     'desc' => 'Complexo com diversos serviços e comércio variado, tudo muito próximo da pousada.'],
    ['nome' => 'Local de Descanso Próximo',   'tipo' => 'Lazer',         'emoji' => '🌿', 'distancia' => '4 min a pé',     'desc' => 'Espaço tranquilo nas proximidades, ótimo para relaxar e respirar ar fresco.'],
    ['nome' => 'Poupatempo e Detran.SP',      'tipo' => 'Serviço Público','emoji' => '🏛️', 'distancia' => '5 min a pé',     'desc' => 'Agência Poupatempo e Detran.SP para documentação, habilitação e serviços estaduais.'],
    ['nome' => 'Rodoviária de Araras',        'tipo' => 'Transporte',    'emoji' => '🚌', 'distancia' => '7 min a pé',     'desc' => 'Terminal rodoviário com linhas para Campinas, Limeira, São Paulo e cidades da região.'],
    ['nome' => 'Centro Histórico de Araras',  'tipo' => 'Cultura',       'emoji' => '🏙️', 'distancia' => '2 min a pé',     'desc' => 'Praças, comércio local e arquitetura histórica — tudo a poucos passos da pousada.'],
    ['nome' => 'Campinas',                    'tipo' => 'Passeio',       'emoji' => '🏢', 'distancia' => '45 min de carro','desc' => 'Metrópole com vasta oferta cultural: Unicamp, shoppings, parques e gastronomia diversa.'],
    ['nome' => 'Limeira',                     'tipo' => 'Passeio',       'emoji' => '💎', 'distancia' => '30 min de carro','desc' => 'A "Capital Mundial da Joalheria" com shoppings, Outlet Premium e parques.'],
];
?>

<section class="section section--bege" style="padding-top:3rem;padding-bottom:2rem">
  <div class="container text-center">
    <span class="section-label">Descubra a região</span>
    <h1 class="section-title">Atrações próximas</h1>
    <p class="section-sub">Araras e região têm muito a oferecer. Tudo a poucos minutos da Pousada Barão!</p>
  </div>
</section>

<!-- FOTO REAL DOS PONTOS PRÓXIMOS -->
<section class="section" style="padding-top:1rem;padding-bottom:2rem">
  <div class="container">
    <figure style="margin:0">
      <img
        src="/pousada_barao/img/pontos_proximos.png"
        alt="Pontos próximos à Pousada Barão em Araras SP"
        style="width:100%;border-radius:14px;box-shadow:0 6px 30px rgba(0,0,0,0.12);display:block"
      >
      <figcaption style="text-align:center;font-size:0.82rem;color:#888;margin-top:0.6rem">
        Pontos de referência a poucos minutos da Pousada Barão – Araras, SP
      </figcaption>
    </figure>
  </div>
</section>

<!-- CARDS -->
<section class="section section--cinza">
  <div class="container">
    <div class="text-center" style="margin-bottom:2rem">
      <span class="section-label">Detalhes</span>
      <h2 class="section-title">O que está por perto</h2>
    </div>
    <div class="rooms-grid">
      <?php foreach ($atracoes as $a): ?>
        <div class="room-card">
          <div class="room-card__img" style="font-size:2.8rem;height:120px"><?= $a['emoji'] ?></div>
          <div class="room-card__body">
            <div class="room-card__qty"><?= $a['tipo'] ?> · <?= $a['distancia'] ?></div>
            <div class="room-card__title"><?= $a['nome'] ?></div>
            <p class="room-card__desc"><?= $a['desc'] ?></p>
            <div class="room-card__footer">
              <span class="room-card__badge">📍 <?= $a['distancia'] ?></span>
              <a href="https://wa.me/<?= POUSADA_WHATSAPP ?>?text=Olá!%20Preciso%20de%20dicas%20sobre%20<?= urlencode($a['nome']) ?>."
                 class="btn btn-primary" target="_blank" style="font-size:0.8rem;padding:0.5rem 1rem">Pedir dica</a>
            </div>
          </div>
        </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<section class="section" style="background:var(--verde-escuro);text-align:center;padding:4rem 1.5rem">
  <span class="section-label" style="color:var(--verde-claro)">Pronto para explorar?</span>
  <h2 style="color:var(--branco);margin-bottom:1rem">Reserve seu quarto</h2>
  <p style="color:rgba(255,255,255,0.75);margin-bottom:2rem">Venha se hospedar e conhecer tudo que Araras tem a oferecer!</p>
  <div style="display:flex;gap:1rem;justify-content:center;flex-wrap:wrap">
    <a href="quartos.php" class="btn btn-primary" style="background:var(--verde-claro)">Ver quartos</a>
    <a href="https://wa.me/<?= POUSADA_WHATSAPP ?>?text=Olá!%20Quero%20uma%20reserva." class="btn btn-wa" target="_blank">📱 WhatsApp</a>
  </div>
</section>

<?php require_once '../includes/footer.php'; ?>
