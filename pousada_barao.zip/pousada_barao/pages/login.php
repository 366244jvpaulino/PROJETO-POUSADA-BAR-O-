<?php
// pages/login.php
$page_title = 'Entrar';
require_once '../includes/config.php';

if (isset($_SESSION['usuario_nome'])) {
    header('Location: /pousada_barao/index.php'); exit;
}

$erro = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $tipo  = $_POST['tipo']  ?? 'cliente';
    $email = trim($_POST['email'] ?? '');
    $senha = trim($_POST['senha'] ?? '');

    if ($email && $senha) {
        $arquivo = '../usuarios.txt';
        $encontrado = false;
        if (file_exists($arquivo)) {
            foreach (file($arquivo, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) as $linha) {
                $d = explode('|', $linha);
                if (count($d) >= 4 && trim($d[2]) === $email
                    && password_verify($senha, trim($d[3]))
                    && trim($d[0]) === $tipo) {
                    $_SESSION['usuario_nome']  = trim($d[1]);
                    $_SESSION['usuario_email'] = trim($d[2]);
                    $_SESSION['usuario_tipo']  = trim($d[0]);
                    $encontrado = true;
                    header('Location: /pousada_barao/index.php'); exit;
                }
            }
        }
        if (!$encontrado) $erro = 'E-mail, senha ou tipo de conta incorretos.';
    } else {
        $erro = 'Preencha todos os campos.';
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width,initial-scale=1.0">
  <title>Entrar | <?= POUSADA_NOME ?></title>
  <link rel="stylesheet" href="/pousada_barao/css/style.css">
</head>
<body>

<div class="auth-wrapper">
  <div class="auth-card">

    <div class="auth-card__logo">
      <img src="/pousada_barao/img/cartao_visita.jpg" alt="Logo Pousada Barão"
           style="width:160px;border-radius:10px;margin:0 auto 1rem;display:block;box-shadow:0 4px 14px rgba(0,0,0,0.12)">
      <h2>Entrar na sua conta</h2>
      <p>Acesse para gerenciar suas reservas</p>
    </div>

    <!-- Abas cliente / empresa -->
    <form method="POST" action="">
      <div class="auth-tabs">
        <label class="auth-tab <?= ($_POST['tipo'] ?? 'cliente') === 'cliente' ? 'active' : '' ?>"
               onclick="setTipo('cliente')">👤 Cliente</label>
        <label class="auth-tab <?= ($_POST['tipo'] ?? '') === 'empresa' ? 'active' : '' ?>"
               onclick="setTipo('empresa')">🏢 Empresa</label>
      </div>
      <input type="hidden" name="tipo" id="tipo" value="<?= htmlspecialchars($_POST['tipo'] ?? 'cliente') ?>">

      <?php if ($erro): ?>
        <div class="alert alert-danger">⚠️ <?= $erro ?></div>
      <?php endif; ?>

      <div class="form-group">
        <label for="email">E-mail</label>
        <input type="email" id="email" name="email" placeholder="seu@email.com"
               value="<?= htmlspecialchars($_POST['email'] ?? '') ?>" required>
      </div>
      <div class="form-group">
        <label for="senha">Senha</label>
        <input type="password" id="senha" name="senha" placeholder="Sua senha" required>
      </div>
      <button type="submit" class="btn btn-primary" style="width:100%;margin-bottom:1rem">Entrar</button>
    </form>

    <div class="auth-footer">
      Não tem conta? <a href="cadastro.php">Cadastre-se</a>
      &nbsp;·&nbsp;
      <a href="/pousada_barao/index.php">← Voltar ao site</a>
    </div>
  </div>
</div>

<script>
function setTipo(v) {
  document.getElementById('tipo').value = v;
  document.querySelectorAll('.auth-tab').forEach(t => t.classList.remove('active'));
  event.target.classList.add('active');
}
</script>
</body>
</html>
