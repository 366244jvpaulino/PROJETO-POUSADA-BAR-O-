<?php
// pages/contato.php
$page_title = 'Contato';
require_once '../includes/header.php';

$msg = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome     = trim(htmlspecialchars($_POST['nome']     ?? ''));
    $email    = trim(htmlspecialchars($_POST['email']    ?? ''));
    $assunto  = trim(htmlspecialchars($_POST['assunto']  ?? ''));
    $mensagem = trim(htmlspecialchars($_POST['mensagem'] ?? ''));

    if ($nome && $email && $mensagem) {
        $linha = date('d/m/Y H:i') . " | $nome | $email | $assunto | $mensagem\n";
        file_put_contents('../mensagens.txt', $linha, FILE_APPEND | LOCK_EX);
        $headers = "From: $email\r\nReply-To: $email\r\nContent-Type: text/plain; charset=UTF-8";
        @mail(POUSADA_EMAIL, "Contato: $assunto", $mensagem, $headers);
        $msg = 'ok';
    } else {
        $msg = 'erro';
    }
}
?>

<section class="section section--bege" style="padding-top:3rem;padding-bottom:2rem">
  <div class="container text-center">
    <span class="section-label">Fale conosco</span>
    <h1 class="section-title">Contato</h1>
    <p class="section-sub">Estamos aqui para ajudar. Escolha o canal de sua preferência.</p>
  </div>
</section>

<section class="section">
  <div class="container">
    <div class="contato-grid">

      <!-- Coluna esquerda: cartão + links -->
      <div>
        <!-- CARTÃO DE VISITA REAL -->
        <div style="margin-bottom:1.75rem">
          <img
            src="/pousada_barao/img/cartao_visita.jpg"
            alt="Cartão de visita da Pousada Barão – Araras SP"
            style="width:100%;border-radius:14px;box-shadow:0 6px 24px rgba(0,0,0,0.13);display:block"
          >
        </div>

        <span class="section-label">Canais de atendimento</span>
        <h2 class="section-title" style="font-size:1.5rem">Prefere falar diretamente?</h2>
        <p style="margin-bottom:1.5rem;color:#666">Respondemos rapidamente nos horários de atendimento.</p>

        <div class="contato-links">

          <a href="https://wa.me/<?= POUSADA_WHATSAPP ?>?text=Olá!%20Gostaria%20de%20informações%20sobre%20a%20Pousada%20Barão."
             class="contato-link-btn" target="_blank" rel="noopener">
            <span class="icon">📱</span>
            <div>
              <div style="font-size:0.76rem;color:#888;margin-bottom:2px">WhatsApp</div>
              <strong><?= POUSADA_WHATSAPP_EXIBE ?></strong>
            </div>
          </a>

          <a href="tel:+551933527705" class="contato-link-btn">
            <span class="icon">☎️</span>
            <div>
              <div style="font-size:0.76rem;color:#888;margin-bottom:2px">Telefone fixo</div>
              <strong><?= POUSADA_TELEFONE ?></strong>
            </div>
          </a>

          <a href="<?= POUSADA_INSTAGRAM ?>" class="contato-link-btn" target="_blank" rel="noopener">
            <span class="icon">📸</span>
            <div>
              <div style="font-size:0.76rem;color:#888;margin-bottom:2px">Instagram</div>
              <strong>@pousada.barao</strong>
            </div>
          </a>

          <div class="contato-link-btn" style="cursor:default">
            <span class="icon">📍</span>
            <div>
              <div style="font-size:0.76rem;color:#888;margin-bottom:2px">Endereço</div>
              <?= POUSADA_ENDERECO ?>
            </div>
          </div>

          <div class="contato-link-btn" style="cursor:default">
            <span class="icon">🕐</span>
            <div>
              <div style="font-size:0.76rem;color:#888;margin-bottom:2px">Horário</div>
              <?= POUSADA_HORARIO ?>
            </div>
          </div>

        </div>
      </div>

      <!-- Coluna direita: formulário -->
      <div>
        <span class="section-label">Formulário</span>
        <h2 class="section-title" style="font-size:1.5rem">Envie uma mensagem</h2>
        <p style="margin-bottom:1.5rem;color:#666">Respondemos em até 24h úteis.</p>

        <?php if ($msg === 'ok'): ?>
          <div class="form-msg form-msg--ok">✅ Mensagem enviada! Entraremos em contato em breve.</div>
        <?php elseif ($msg === 'erro'): ?>
          <div class="form-msg form-msg--err">⚠️ Preencha todos os campos obrigatórios.</div>
        <?php endif; ?>

        <form method="POST" action="">
          <div class="form-row">
            <div class="form-group">
              <label for="nome">Nome completo *</label>
              <input type="text" id="nome" name="nome" placeholder="Seu nome" required>
            </div>
            <div class="form-group">
              <label for="email">E-mail *</label>
              <input type="email" id="email" name="email" placeholder="seu@email.com" required>
            </div>
          </div>
          <div class="form-group">
            <label for="assunto">Assunto</label>
            <select id="assunto" name="assunto">
              <option value="Reserva">Solicitar reserva</option>
              <option value="Informações">Informações sobre quartos</option>
              <option value="Preços">Preços e disponibilidade</option>
              <option value="Outro">Outro assunto</option>
            </select>
          </div>
          <div class="form-group">
            <label for="mensagem">Mensagem *</label>
            <textarea id="mensagem" name="mensagem" placeholder="Escreva sua mensagem..." required></textarea>
          </div>
          <button type="submit" class="btn btn-primary" style="width:100%">✉️ Enviar mensagem</button>
        </form>
      </div>

    </div>
  </div>
</section>

<!-- MAPA -->
<section class="section--bege" style="padding:3rem 1.5rem">
  <div class="container">
    <div class="text-center" style="margin-bottom:1.5rem">
      <h3 style="color:var(--verde-escuro)">📍 Como nos encontrar</h3>
      <p style="color:#666"><?= POUSADA_ENDERECO ?></p>
    </div>
    <div class="mapa-wrapper">
      <iframe
        src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3685.5!2d-47.3833!3d-22.3572!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zMjLCsDIxJzI1LjkiUyA0N8KwMjMnMDEuOSJX!5e0!3m2!1spt-BR!2sbr!4v1700000000000"
        allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"
        title="Localização da Pousada Barão em Araras SP">
      </iframe>
    </div>
  </div>
</section>

<?php require_once '../includes/footer.php'; ?>
