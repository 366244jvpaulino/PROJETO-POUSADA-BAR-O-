<?php
// ============================================================
//  config.php – Configurações centrais da Pousada Barão
//  Altere os dados aqui para refletir em todo o site
// ============================================================

define('POUSADA_NOME',      'Pousada Barão');
define('POUSADA_SLOGAN',    'Seu lar em Araras – conforto e tranquilidade');
define('POUSADA_ENDERECO',  'R. Nunes Machado, 623 - Centro, Araras - SP, 13600-020');
define('POUSADA_HORARIO',   'Segunda a Domingo: 8h às 22h');
define('POUSADA_WHATSAPP',  '5519996544617');          // Formato internacional sem espaços
define('POUSADA_WHATSAPP_EXIBE', '+55 19 99654-4617'); // Exibição para o usuário
define('POUSADA_INSTAGRAM', 'https://www.instagram.com/pousada.barao');
define('POUSADA_TELEFONE',  '(19) 3352-7705');              // Telefone fixo
define('POUSADA_EMAIL',     'contato@pousadabarao.com.br'); // ajuste se necessário

// Quartos disponíveis para agendamento
define('QUARTOS_CONFIG', serialize([
    ['capacidade' => 1, 'quantidade' => 3, 'label' => '1 pessoa',   'emoji' => '🛏️'],
    ['capacidade' => 2, 'quantidade' => 4, 'label' => '2 pessoas',  'emoji' => '🛏️'],
    ['capacidade' => 3, 'quantidade' => 5, 'label' => '3 pessoas',  'emoji' => '🛏️'],
    ['capacidade' => 7, 'quantidade' => 1, 'label' => '7 pessoas',  'emoji' => '🏠'],
    ['capacidade' => 8, 'quantidade' => 1, 'label' => '8 pessoas',  'emoji' => '🏠'],
]));

// Serviços oferecidos
define('SERVICOS', serialize([
    ['icon' => '☕', 'nome' => 'Café da manhã'],
    ['icon' => '🧹', 'nome' => 'Limpeza dos quartos'],
    ['icon' => '👕', 'nome' => 'Lavanderia'],
    ['icon' => '📺', 'nome' => 'TV'],
    ['icon' => '📶', 'nome' => 'Wi-Fi grátis'],
    ['icon' => '🚿', 'nome' => 'Banheiros compartilhados'],
]));

// Sessão iniciada aqui para uso em todas as páginas
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
