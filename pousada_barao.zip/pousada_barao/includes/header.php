<?php
// includes/header.php
// Incluído no topo de TODAS as páginas
require_once __DIR__ . '/config.php';

$pagina_atual = basename($_SERVER['PHP_SELF']);
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="<?= POUSADA_NOME ?> – <?= POUSADA_SLOGAN ?>. Localizada no centro de Araras, SP.">
  <title><?= isset($page_title) ? $page_title . ' | ' : '' ?><?= POUSADA_NOME ?></title>
  <link rel="stylesheet" href="/pousada_barao/css/style.css">
</head>
<body>

<!-- ===== NAVBAR ===== -->
<nav class="navbar" id="navbar">
  <div class="navbar__inner">

    <!-- Logo -->
    <a href="/pousada_barao/index.php" class="navbar__logo">
      🏡 <?= POUSADA_NOME ?> <span>Araras</span>
    </a>

    <!-- Botão hambúrguer (mobile) -->
    <button class="navbar__toggle" id="navToggle" aria-label="Abrir menu">
      <span></span><span></span><span></span>
    </button>

    <!-- Links de navegação -->
    <div class="navbar__links" id="navLinks">
      <a href="/pousada_barao/index.php"
         class="<?= $pagina_atual === 'index.php' ? 'active' : '' ?>">Início</a>
      <a href="/pousada_barao/pages/quartos.php"
         class="<?= $pagina_atual === 'quartos.php' ? 'active' : '' ?>">Quartos</a>
      <a href="/pousada_barao/pages/atracoes.php"
         class="<?= $pagina_atual === 'atracoes.php' ? 'active' : '' ?>">Atrações</a>
      <a href="/pousada_barao/pages/contato.php"
         class="<?= $pagina_atual === 'contato.php' ? 'active' : '' ?>">Contato</a>
    </div>

    <!-- Botões de autenticação -->
    <div class="navbar__auth" id="navAuth">
      <?php if (isset($_SESSION['usuario_nome'])): ?>
        <span style="color:#ccc;font-size:0.88rem;align-self:center">
          Olá, <?= htmlspecialchars($_SESSION['usuario_nome']) ?>
        </span>
        <a href="/pousada_barao/pages/logout.php" class="btn btn-outline">Sair</a>
      <?php else: ?>
        <a href="/pousada_barao/pages/login.php" class="btn btn-outline">Entrar</a>
        <a href="/pousada_barao/pages/cadastro.php" class="btn btn-primary">Cadastrar</a>
      <?php endif; ?>
    </div>

  </div>
</nav>

<!-- Botão WhatsApp flutuante -->
<a href="https://wa.me/<?= POUSADA_WHATSAPP ?>?text=Olá!%20Gostaria%20de%20informações%20sobre%20a%20Pousada%20Barão."
   class="whatsapp-float" target="_blank" rel="noopener" title="Fale conosco no WhatsApp">
  📱
</a>

<script>
// Menu mobile
const toggle = document.getElementById('navToggle');
const navbar = document.getElementById('navbar');
toggle.addEventListener('click', () => {
  navbar.classList.toggle('nav-mobile-open');
});
</script>
