<?php
// includes/footer.php
// Incluído no rodapé de TODAS as páginas
require_once __DIR__ . '/config.php';
?>

<!-- ===== FOOTER ===== -->
<footer class="footer">
  <div class="footer__grid">

    <!-- Coluna 1: Marca -->
    <div>
      <div class="footer__logo">🏡 <?= POUSADA_NOME ?></div>
      <p class="footer__desc">
        Localizada no coração de Araras – SP, oferecemos conforto,
        tranquilidade e atendimento personalizado para sua estadia.
      </p>
    </div>

    <!-- Coluna 2: Links rápidos -->
    <div>
      <h4>Navegação</h4>
      <ul class="footer__links">
        <li><a href="/pousada_barao/index.php">Início</a></li>
        <li><a href="/pousada_barao/pages/quartos.php">Quartos</a></li>
        <li><a href="/pousada_barao/pages/atracoes.php">Atrações</a></li>
        <li><a href="/pousada_barao/pages/contato.php">Contato</a></li>
        <li><a href="/pousada_barao/pages/login.php">Entrar</a></li>
        <li><a href="/pousada_barao/pages/cadastro.php">Cadastrar</a></li>
      </ul>
    </div>

    <!-- Coluna 3: Contato -->
    <div>
      <h4>Contato</h4>
      <ul class="footer__links">
        <li>📍 <?= POUSADA_ENDERECO ?></li>
        <li>🕐 <?= POUSADA_HORARIO ?></li>
        <li>
          <a href="https://wa.me/<?= POUSADA_WHATSAPP ?>" target="_blank">
            📱 <?= POUSADA_WHATSAPP_EXIBE ?>
          </a>
        </li>
        <li>
          <a href="<?= POUSADA_INSTAGRAM ?>" target="_blank">
            📸 @pousada.barao
          </a>
        </li>
      </ul>
    </div>

  </div>

  <div class="footer__bottom">
    <span>&copy; <?= date('Y') ?> <?= POUSADA_NOME ?> – Araras, SP. Todos os direitos reservados.</span>
    <span>Desenvolvido com PHP + XAMPP</span>
  </div>
</footer>

</body>
</html>
