# Pousada Barão – Guia de Instalação no XAMPP
## Como rodar o site localmente no seu computador

---

## 1. Pré-requisitos
- XAMPP instalado (https://www.apachefriends.org/pt_br/index.html)
- VS Code instalado
- Navegador (Chrome, Firefox ou Edge)

---

## 2. Estrutura de arquivos do projeto

```
pousada_barao/
│
├── css/
│   └── style.css              ← Toda a estilização do site
│
├── img/
│   ├── cartao_visita.jpg      ← Cartão de visita / logo da pousada
│   └── pontos_proximos.png    ← Foto dos pontos próximos
│
├── includes/
│   ├── config.php             ← ⭐ Configurações centrais (edite aqui)
│   ├── header.php             ← Menu de navegação (aparece em todas as páginas)
│   └── footer.php             ← Rodapé (aparece em todas as páginas)
│
├── pages/
│   ├── quartos.php            ← Página de quartos e agendamento
│   ├── atracoes.php           ← Página de atrações próximas
│   ├── contato.php            ← Formulário de contato
│   ├── login.php              ← Login de cliente / empresa
│   ├── cadastro.php           ← Cadastro de cliente / empresa
│   └── logout.php             ← Encerra a sessão do usuário
│
├── index.php                  ← Página inicial (Home)
│
├── reservas.txt               ← Criado automaticamente ao receber reservas
├── mensagens.txt              ← Criado automaticamente ao receber mensagens
├── usuarios.txt               ← Criado automaticamente ao cadastrar usuários
│
└── README.md                  ← Este arquivo
```

---

## 3. Passo a passo para instalar

### Passo 1 – Abrir o XAMPP
1. Abra o XAMPP Control Panel
2. Clique em **Start** no módulo **Apache**
3. Aguarde aparecer "Running" em verde

### Passo 2 – Copiar o projeto
1. Abra o Windows Explorer
2. Navegue até: `C:\xampp\htdocs\`
3. Cole a pasta **pousada_barao** inteira dentro de `htdocs`

O resultado deve ser: `C:\xampp\htdocs\pousada_barao\`

### Passo 3 – Abrir no navegador
1. Abra o Chrome ou Firefox
2. Digite na barra de endereço: `http://localhost/pousada_barao/`
3. O site vai abrir!

### Passo 4 – Editar no VS Code
1. Abra o VS Code
2. Clique em **File → Open Folder**
3. Selecione a pasta `C:\xampp\htdocs\pousada_barao\`
4. Edite qualquer arquivo e salve — as mudanças aparecem ao recarregar o navegador

---

## 4. Como personalizar

### Alterar dados da pousada
Abra o arquivo `includes/config.php` e edite as linhas com `define(...)`:

```php
define('POUSADA_NOME',      'Pousada Barão');          // Nome do site
define('POUSADA_WHATSAPP',  '5519996544617');           // Número do WhatsApp
define('POUSADA_TELEFONE',  '(19) 3352-7705');          // Telefone fixo
define('POUSADA_HORARIO',   'Segunda a Domingo: 8h às 22h'); // Horário
```

### Adicionar novas fotos
1. Coloque suas fotos na pasta `img/`
2. Referencie no código assim:
   ```html
   <img src="/pousada_barao/img/nome_da_foto.jpg" alt="Descrição">
   ```

---

## 5. Páginas do site

| Endereço no navegador                               | Página           |
|-----------------------------------------------------|------------------|
| `http://localhost/pousada_barao/`                   | Home             |
| `http://localhost/pousada_barao/pages/quartos.php`  | Quartos          |
| `http://localhost/pousada_barao/pages/atracoes.php` | Atrações         |
| `http://localhost/pousada_barao/pages/contato.php`  | Contato          |
| `http://localhost/pousada_barao/pages/login.php`    | Login            |
| `http://localhost/pousada_barao/pages/cadastro.php` | Cadastro         |

---

## 6. Tecnologias utilizadas

- **PHP** – Linguagem de programação do servidor
- **HTML5** – Estrutura das páginas
- **CSS3** – Estilização e responsividade
- **XAMPP** – Servidor local Apache + PHP
- **VS Code** – Editor de código

---

## 7. Observações para o professor

- O projeto **não usa JavaScript** (conforme solicitado)
- O login e cadastro usam **sessões PHP** (`$_SESSION`)
- Os dados são salvos em **arquivos .txt** (sem banco de dados)
- O formulário de contato usa a função **`mail()`** do PHP
- O site é **responsivo** (funciona no celular e no computador) usando somente CSS
- Todas as informações centrais estão em **`includes/config.php`** (princípio DRY)

---

*Desenvolvido com PHP + XAMPP | Pousada Barão – Araras, SP*
